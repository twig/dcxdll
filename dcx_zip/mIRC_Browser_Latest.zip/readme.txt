
mIRC_Browser_Latest.reg

This registry file will enable mIRC (DCX WebControls) to use the latest IE version when displaying sites.
The file changes a single key ([HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION]) & adds mIRC.exe to it.

NB: If you run mIRC from an exe other than mIRC.exe you will need to add it as well.
